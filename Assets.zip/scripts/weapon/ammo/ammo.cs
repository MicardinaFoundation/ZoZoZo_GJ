using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ammo : MonoBehaviour
{
    //public Text ammo_ui;
    //public Text name_weap_UI;
    //int amm_in_magazine;
    //int all_ammo;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //amm_in_magazine = weap_sett.magazine_ammo_weap_ui;
        //all_ammo = weap_sett.ammo_weap_ui;
        //ammo_ui.text = all_ammo + " / " + amm_in_magazine;
    }

}
